create procedure udp_findbyextension(IN extension varchar(100))
  BEGIN
    SELECT f.id,f.name AS caption,CONCAT(size,'KB')AS user
    FROM files f
    WHERE f.name like CONCAT('%.',extension)
    ORDER BY f.id ASC ;
  END;

