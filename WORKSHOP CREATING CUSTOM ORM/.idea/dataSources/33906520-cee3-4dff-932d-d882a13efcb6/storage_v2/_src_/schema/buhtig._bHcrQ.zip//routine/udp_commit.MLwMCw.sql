create procedure udp_commit(IN user varchar(30), IN password varchar(30), IN message varchar(255), IN issue_id int)
  BEGIN

    DECLARE user_id INT;
    DECLARE repository_id INT;
   IF((SELECT COUNT(*) from users WHERE users.username =user))<>1
     THEN
      SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT ='No such user!';
   END IF;

  IF((SELECT  COUNT(*) FROM users WHERE users.username =user AND users.password=password ))<>1
    THEN
       SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT ='Password is incorrect!';
  END IF ;

   IF ((SELECT  COUNT(*) from issues WHERE issues.id=issue_id))<>1
     THEN
       SIGNAL SQLSTATE '45000'
       SET MESSAGE_TEXT ='The issue does not exist!';
     END IF ;
   SET user_id := (SELECT u.id from users u WHERE u.username=user);
   SET repository_id:=(SELECT i.repository_id FROM issues i WHERE i.id=issue_id);


    INSERT into commits(repository_id, contributor_id,issue_id,message)
    VALUE (repository_id,user_id,issue_id,message);

   UPDATE issues
       SET issue_status='closed'
       WHERE issues.id=issue_id;

 END;

