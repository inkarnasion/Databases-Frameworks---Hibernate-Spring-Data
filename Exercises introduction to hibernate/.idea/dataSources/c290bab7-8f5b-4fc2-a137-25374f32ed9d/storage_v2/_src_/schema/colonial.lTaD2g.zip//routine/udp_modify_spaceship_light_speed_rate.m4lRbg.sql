create procedure udp_modify_spaceship_light_speed_rate(IN spaceship_name varchar(50), IN light_speed_rate_increse int)
  begin
    IF((SELECT COUNT(*) from spaceships WHERE name = spaceship_name))<>1
      THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT ='Spaceship you are trying to modify does not exists.';
    END IF;

    update spaceships
       set light_speed_rate = light_speed_rate + light_speed_rate_increse
     where name = spaceship_name;
  end;

