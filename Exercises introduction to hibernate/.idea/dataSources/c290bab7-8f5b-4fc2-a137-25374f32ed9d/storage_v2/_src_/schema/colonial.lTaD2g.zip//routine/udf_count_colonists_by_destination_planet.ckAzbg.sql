create function udf_count_colonists_by_destination_planet(planet_name varchar(30))
  returns int
  begin
    declare result int;

    select count(p.id) into result
      from planets p
      join spaceports s on p.id = s.planet_id
      join journeys j on s.id = j.destination_spaceport_id
      join travel_cards tc on j.id = tc.journey_id
      join colonists c on tc.colonist_id = c.id
     where p.name = planet_name;

    return result;
  end;

