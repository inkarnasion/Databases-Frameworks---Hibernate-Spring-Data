create procedure udp_filter(IN hashtag varchar(10))
  begin
  SELECT p.id,p.caption,
         (SELECT u.username FROM users AS u WHERE p.user_id = u.id )
from posts p 
      where p.caption  like concat('%#',hashtag,'%');
end;

